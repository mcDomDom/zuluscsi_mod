Performance
-----------
Performance characteristics of ZuluSCSI are now documented on the Wiki at https://github.com/ZuluSCSI/ZuluSCSI-firmware/wiki/Performance
