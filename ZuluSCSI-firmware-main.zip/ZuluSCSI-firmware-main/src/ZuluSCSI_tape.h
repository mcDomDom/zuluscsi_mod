// Tape device emulation
// Will be called by scsi.c from SCSI2SD.

#pragma once

extern "C" int scsiTapeCommand();